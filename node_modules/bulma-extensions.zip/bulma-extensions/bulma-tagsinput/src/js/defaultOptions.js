const defaultOptions = {
	disabled: false,
	delimiter: ',',
	allowDelete: true,
	lowercase: false,
	uppercase: false,
	duplicates: true
};
  
export default defaultOptions;
  