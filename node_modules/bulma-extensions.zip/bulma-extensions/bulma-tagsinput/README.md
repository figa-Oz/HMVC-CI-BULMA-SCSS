# bulma-taginputs
Bulma.io extension to add interaction on input tags
(find all my bulma's extensions [here](https://wikiki.github.io/))

[![npm](https://img.shields.io/npm/v/bulma-tagsinput.svg)](https://www.npmjs.com/package/bulma-tagsinput)
[![npm](https://img.shields.io/npm/dm/bulma-tagsinput.svg)](https://www.npmjs.com/package/bulma-tagsinput)
[![Build Status](https://travis-ci.org/Wikiki/bulma-tagsinput.svg?branch=master)](https://travis-ci.org/Wikiki/bulma-tagsinput)

Documentation & Demo
---
You can find the Documentation and a demo [here](https://wikiki.github.io/form/tagsinput/)
