# bulma-switch
Bulma's extension to display checkbox as a toggle button
(find all my bulma's extensions [here](https://wikiki.github.io/))

[![npm](https://img.shields.io/npm/v/bulma-switch.svg)](https://www.npmjs.com/package/bulma-switch)
[![npm](https://img.shields.io/npm/dm/bulma-switch.svg)](https://www.npmjs.com/package/bulma-switch)
[![Build Status](https://travis-ci.org/Wikiki/bulma-switch.svg?branch=master)](https://travis-ci.org/Wikiki/bulma-switch)

![Switch example](switch-example.png)

Documentation & Demo
---
You can find the Documentation and a demo [here](https://wikiki.github.io/form/switch/)
