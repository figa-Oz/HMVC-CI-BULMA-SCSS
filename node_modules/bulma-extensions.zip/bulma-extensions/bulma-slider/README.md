# bulma-slider
Bulma's extension to display sliders
(find all my bulma's extensions [here](https://wikiki.github.io/))

[![npm](https://img.shields.io/npm/v/bulma-slider.svg)](https://www.npmjs.com/package/bulma-slider)
[![npm](https://img.shields.io/npm/dm/bulma-slider.svg)](https://www.npmjs.com/package/bulma-slider)
[![Build Status](https://travis-ci.org/Wikiki/bulma-slider.svg?branch=master)](https://travis-ci.org/Wikiki/bulma-slider)

<img src="./slider-example.png" width="100%">

Documentation & Demo
---
You can find the Documentation and a demo [here](https://wikiki.github.io/form/slider/)

Thanks
--
Thanks to Chris Coyier for his article on [CSS-Tricks](https://css-tricks.com/value-bubbles-for-range-inputs)
