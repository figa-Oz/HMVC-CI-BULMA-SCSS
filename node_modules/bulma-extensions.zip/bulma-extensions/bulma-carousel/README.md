# bulma-carousel
Display a carousel

(find all my bulma's extensions [here](https://wikiki.github.io))

[![npm](https://img.shields.io/npm/v/bulma-carousel.svg)](https://www.npmjs.com/package/bulma-carousel)
[![npm](https://img.shields.io/npm/dm/bulma-carousel.svg)](https://www.npmjs.com/package/bulma-carousel)
[![Build Status](https://travis-ci.org/Wikiki/bulma-carousel.svg?branch=master)](https://travis-ci.org/Wikiki/bulma-carousel)

Documentation & Demo
---
You can find the Documentation and a demo [here](https://wikiki.github.io/components/carousel)
