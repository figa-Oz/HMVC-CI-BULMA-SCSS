# bulma-calendar
Bulma's extension to display a calendar. It can be used on page as modal/popup for datepicker.
(find all my bulma's extensions [here](https://wikiki.github.io/))

[![npm](https://img.shields.io/npm/v/bulma-calendar.svg)](https://www.npmjs.com/package/bulma-calendar)
[![npm](https://img.shields.io/npm/dm/bulma-calendar.svg)](https://www.npmjs.com/package/bulma-calendar)
[![Build Status](https://travis-ci.org/Wikiki/bulma-calendar.svg?branch=master)](https://travis-ci.org/Wikiki/bulma-calendar)

Thanks to @stevensacks for his help.

Documentation & Demo
---
Full Documentation and demo are avaible on [CreativeBulma](https://creativebulma.net/product/calendar/)
