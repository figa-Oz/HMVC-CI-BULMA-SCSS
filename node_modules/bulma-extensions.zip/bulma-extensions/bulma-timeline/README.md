# bulma-timeline
Bulma's extension to display a timeline
(find all my bulma's extensions [here](https://wikiki.github.io/))

[![npm](https://img.shields.io/npm/v/bulma-timeline.svg)](https://www.npmjs.com/package/bulma-timeline)
[![npm](https://img.shields.io/npm/dm/bulma-timeline.svg)](https://www.npmjs.com/package/bulma-timeline)
[![Build Status](https://travis-ci.org/Wikiki/bulma-timeline.svg?branch=master)](https://travis-ci.org/Wikiki/bulma-timeline)

<img src="https://img4.hostingpics.net/pics/887099ScreenShot20170812at150229.png" width="50%">

Documentation & Demo
---
You can find the Documentation and a demo [here](https://wikiki.github.io/components/timeline/)
