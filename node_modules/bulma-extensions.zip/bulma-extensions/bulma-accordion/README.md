# bulma-accordion
A simple accordion extension for Bulma
(find all my bulma's extensions [here](https://wikiki.github.io/))

[![npm](https://img.shields.io/npm/v/bulma-accordion.svg)](https://www.npmjs.com/package/bulma-accordion)
[![npm](https://img.shields.io/npm/dm/bulma-accordion.svg)](https://www.npmjs.com/package/bulma-accordion)
[![Build Status](https://travis-ci.org/Wikiki/bulma-accordion.svg?branch=master)](https://travis-ci.org/Wikiki/bulma-accordion)

Documentation & Demo
---
You can find the Documentation and a demo [here](https://wikiki.github.io/components/accordion/)
