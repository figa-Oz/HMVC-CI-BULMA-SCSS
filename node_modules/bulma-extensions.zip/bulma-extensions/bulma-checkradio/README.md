# bulma-checkradio
Bulma's extension to display better checkbox and radio imputs
(find all my bulma's extensions [here](https://wikiki.github.io/))

[![npm](https://img.shields.io/npm/v/bulma-checkradio.svg)](https://www.npmjs.com/package/bulma-checkradio)
[![npm](https://img.shields.io/npm/dm/bulma-checkradio.svg)](https://www.npmjs.com/package/bulma-checkradio)
[![Build Status](https://travis-ci.org/Wikiki/bulma-checkradio.svg?branch=master)](https://travis-ci.org/Wikiki/bulma-checkradio)

<img src="./checkradio-example.png" width="100%">

Documentation & Demo
---
You can find the Documentation and a demo [here](https://wikiki.github.io/form/checkradio/)
