# bulma-tooltip
Bulma's extension to display tooltip on desktop layout
(find all my bulma's extensions [here](https://wikiki.github.io/))

[![npm](https://img.shields.io/npm/v/bulma-tooltip.svg)](https://www.npmjs.com/package/bulma-tooltip)
[![npm](https://img.shields.io/npm/dm/bulma-tooltip.svg)](https://www.npmjs.com/package/bulma-tooltip)
[![Build Status](https://travis-ci.org/Wikiki/bulma-tooltip.svg?branch=master)](https://travis-ci.org/Wikiki/bulma-tooltip)

Documentation & Demo
---
You can find the Documentation and a demo [here](https://wikiki.github.io/elements/tooltip/)
