# bulma-badge
Bulma's extension element named "badge" to display a number on text, button, ...
(find all my bulma's extensions [here](https://wikiki.github.io/))

[![npm](https://img.shields.io/npm/v/bulma-badge.svg)](https://www.npmjs.com/package/bulma-badge)
[![npm](https://img.shields.io/npm/dm/bulma-badge.svg)](https://www.npmjs.com/package/bulma-badge)
[![Build Status](https://travis-ci.org/Wikiki/bulma-badge.svg?branch=master)](https://travis-ci.org/Wikiki/bulma-badge)

<img src="https://img15.hostingpics.net/pics/241524ScreenShot20170726at124229.png" width="50%">

Documentation & Demo
---
You can find the Documentation and a demo [here](https://wikiki.github.io/elements/badge/)
