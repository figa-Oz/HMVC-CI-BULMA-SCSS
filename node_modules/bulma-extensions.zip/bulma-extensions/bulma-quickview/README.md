# bulma-quickview
Bulma's extension to display quick view of data without leaving the current page
(find all my bulma's extensions [here](https://wikiki.github.io/))

[![npm](https://img.shields.io/npm/v/bulma-quickview.svg)](https://www.npmjs.com/package/bulma-quickview)
[![npm](https://img.shields.io/npm/dm/bulma-quickview.svg)](https://www.npmjs.com/package/bulma-quickview)
[![Build Status](https://travis-ci.org/Wikiki/bulma-quickview.svg?branch=master)](https://travis-ci.org/Wikiki/bulma-quickview)

Documentation & Demo
---
You can find the Documentation and a demo [here](https://wikiki.github.io/components/quickview/)
