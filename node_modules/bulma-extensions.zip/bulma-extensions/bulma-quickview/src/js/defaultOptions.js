const defaultOptions = {
};

export default defaultOptions;
