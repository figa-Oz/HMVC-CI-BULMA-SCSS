## Bug fixes

* Default color