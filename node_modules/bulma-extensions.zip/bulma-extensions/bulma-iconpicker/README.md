# bulma-iconpicker
A wonderful customizable icon picker for your Bulma project
(find all my bulma's extensions [here](https://wikiki.github.io/))

[![npm](https://img.shields.io/npm/v/bulma-iconpicker.svg)](https://www.npmjs.com/package/bulma-iconpicker)
[![npm](https://img.shields.io/npm/dm/bulma-iconpicker.svg)](https://www.npmjs.com/package/bulma-iconpicker)
[![Build Status](https://travis-ci.org/Wikiki/bulma-iconpicker.svg?branch=master)](https://travis-ci.org/Wikiki/bulma-iconpicker)

Documentation & Demo
---
You can find the Documentation and a demo [here](https://wikiki.github.io/form/iconpicker/)
